//
//  CinemaApp.swift
//  Cinema
//
//  Created by Student on 10.12.2022.
//

import SwiftUI

@main
struct CinemaApp: App {
    var body: some Scene {
        WindowGroup {
            SignIn()
        }
    }
}
